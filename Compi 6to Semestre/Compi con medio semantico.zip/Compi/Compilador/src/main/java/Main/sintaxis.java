/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

public class sintaxis {

    String errores[][] = {
        //0                     1
        /*0*/{"Se espera la palablra 'algoritmo'", "301"},
        /*1*/ {"Se esperaba un identificador", "302"},
        /*2*/ {"Se esperaba el simbolo (", "303"},
        /*3*/ {"Se esperaba el simbolo )", "304"},
        /*4*/ {"Se esperaba la palabra 'es'", "305"},
        /*5*/ {"Se esperaba el simbolo ':'", "306"},
        /*6*/ {"Se esperaba un tipo de variable: 'entero', 'decimal', 'cadena' o 'logico'", "307"},
        /*7*/ {"Se esperaba un asignador :=", "308"},
        /*8*/ {"Se espeaba la palabra 'fin'", "309"},
        /*9*/ {"Algoritmo cerrado, escribe codigo entre las etiquetas 'algoritmo' y 'fin'", "310"},
        /*10*/ {"Se esperaba un simbolo ;", "311"},
        /*11*/ {"Se esperaba un operador aritmetico (+, -, /, *) o un ''", "312"},
        /*12*/ {"se esperaba la palabra 'inicio'", "313"},
        /*13*/ {"Se espera una accion", "314"},
        /*14*/ {"Se espera 'fin_mientras' ", "315"},
        /*14*/ {"Se espera 'fin_si' ", "316"},
        /*11*/ {"Se esperaba un operador relacional (>, <, >=,<=,<>, =)", "317"},};

    //Errores despues de 330 son semantico
    String erroresSemantico[][] = {
        /*0*/{"Error semantico nombre de algoritmo duplicado", "330"},
        /*1*/ {"Error semantico variable ya declarada", "331"},};

    nodo p;
    boolean errorEncontrado = false;
    String temporalSemantico, lexemaSemantico;
    int tipoSemantico;
    nodoSemantico cabezaSemantico = null, pSemantico, recorridoSemantico;

    sintaxis(nodo cabeza) {
        p = cabeza;
        try {
            while (p != null) {
                if (p.token == 214) { //algoritmo
                    p = p.sig;
                    if (p.token == 100) { //identificador

                        temporalSemantico = p.lexema;

                        p = p.sig;
                        if (p.token == 115) { // (
                            p = p.sig;
                            if (p.token == 116) { // )
                                p = p.sig;
                                if (p.token == 215) { //es
                                    p = p.sig;
                                    decVariable();
                                    if (p.token == 216) {//inicio
                                        accion();
                                        if (p.token == 217) { //fin                                            
                                            p = null;
                                        } else {
                                            imprimirMensajeError(309);//esperaba fin
                                        }
                                    } else {
                                        imprimirMensajeError(313); //esperaba inicio
                                    }
                                } else {
                                    imprimirMensajeError(305);//se esperaba la palabra 'es'
                                }
                            } else {
                                imprimirMensajeError(304); //se esperaba el simbolo ')'
                            }
                        } else {
                            imprimirMensajeError(303); //se esperaba el simbolo '('
                        }
                    } else {
                        imprimirMensajeError(302); //se esperaba un identificador
                    }
                } else {
                    imprimirMensajeError(301); //se esperaba la palabra 'algoritmo'
                }
            }
        } catch (Exception e) {
            System.out.println("Fin de archivo inesperado");
        }
    }

    private void decVariable() {
        if (p.token == 100) { //identificador
            if (p.lexema.equals(temporalSemantico)) {

                imprimirMensajeErrorSemantico(330); //error semantico nombre de algoritmo duplicado

            }
            //primero checar valores nodosSemanticos con un for o algo asi y arrojar error de duplicado
            checarVariablesSemantico();
            //Agregar nodoSemantico.lexma
            lexemaSemantico = p.lexema;

            p = p.sig;
            if (p.token == 119) { // simbolo :
                p = p.sig;
                if (p.token == 218 || p.token == 219 || p.token == 220 || p.token == 221) { // tipos de variables
                    //agregar nodoSemantico.tipo
                    tipoSemantico = p.token;

                    p = p.sig;

                    //avanzar nodoSemantico
                    insertarNodoSemantico();
                    if (p.token == 118) {  // ;
                        p = p.sig;
                        decVariable();
                    }
                } else {
                    imprimirMensajeError(307); //Se esperaba un tipo de variable
                }
            } else {
                imprimirMensajeError(306); //se esperaba el sibmolo ':'
            }
        } else {
            imprimirMensajeError(302); //se esperaba un identificador
        }

    }

    private void insertarNodoSemantico() {
        nodoSemantico nodoSemantico = new nodoSemantico(lexemaSemantico, tipoSemantico);

        if (cabezaSemantico == null) {
            cabezaSemantico = nodoSemantico;
            pSemantico = cabezaSemantico;
            recorridoSemantico = cabezaSemantico;
        } else {
            pSemantico.sig = nodoSemantico;
            pSemantico = nodoSemantico;
        }
    }

    private void imprimirMensajeError(int numerror) {
        for (String[] error : errores) {
            if (numerror == Integer.valueOf(error[1])) {
                System.out.println("El error encontrado es: " + error[0] + " error " + numerror + " en el renglon " + p.renglon);
            }
        }
        errorEncontrado = true;
        p = null;
    }

    private void imprimirMensajeErrorSemantico(int numerror) {
        for (String[] error : erroresSemantico) {
            if (numerror == Integer.valueOf(error[1])) {
                System.out.println("El error encontrado es: " + error[0] + " error " + numerror + " en el renglon " + p.renglon);
            }
        }
        errorEncontrado = true;
        p = null;
    }

    private void accion() {
        p = p.sig;
        switch (p.token) {
            case 100:  //identificador
                p = p.sig;
                if (p.token == 114) {// :=
                    p = p.sig;
                    expresionNumerica();
                }
                break;

            case 205: //leer
                leer();
                break;
            case 206: //escribir
                escribir();
                break;
            case 207: //si
                si();
                break;
            case 211: // mientras
                mientras();
            default:
                          
                break;
        }

        if (p.token == 118) { // ;
            accion();
        }
    }

    private void expresionNumerica() {
        switch (p.token) {
            case 115: // (
                p = p.sig;
                expresionNumerica();

                if (p.token == 116) { // )
                    p = p.sig;
                    expresionNumerica1();
                } else {
                    imprimirMensajeError(304); // se espera )
                }
                break;
            case 105: // -
                p = p.sig;
                expresionNumerica();
                expresionNumerica1();
                break;
            case 100: // id     
                p = p.sig;
                expresionNumerica1();
                break;
            case 101: // num entero       
                p = p.sig;
                expresionNumerica1();
                break;
            case 102: // num decimal    
                p = p.sig;
                expresionNumerica1();

                break;
            case 203: // true
                p = p.sig;
                expresionNumerica1();
                break;
            case 204: //false    
                p = p.sig;
                expresionNumerica1();
                break;
            case 103: //cadena       
                p = p.sig;
                expresionNumerica1();
                break;
            default:
                break;
        }
    }

    private void expresionNumerica1() {

        switch (p.token) {
            case 104: // +    
                p = p.sig;
                expresionNumerica();
                expresionNumerica1();
                break;
            case 105: // -
                p = p.sig;
                expresionNumerica();
                expresionNumerica1();
                break;
            case 106: // *
                p = p.sig;
                expresionNumerica();
                expresionNumerica1();
                break;
            case 107: // /
                p = p.sig;
                expresionNumerica();
                expresionNumerica1();
                break;
            default:
                break;
        }
    }

    private void expresionLogica() {
        p = p.sig;
        switch (p.token) {
            case 115: // (
                expresionLogica();
                if (p.token == 116) { // )  
                    p = p.sig;
                } else {
                    imprimirMensajeError(304); // se espera )
                }

                break;
            case 202: // not
                expresionLogica();
                expresionLogica1();
                break;
            case 100: // id                               
                if (p.sig.token == 108 || p.sig.token == 110 || p.sig.token == 109 || p.sig.token == 111 || p.sig.token == 113 || p.sig.token == 112 || p.sig.token == 203 || p.sig.token == 204) { // operador relacional >, < >=, <=, <>, =                    
                    expresionRelacional();
                    expresionLogica1();

                } else {
                    p = p.sig;
                    expresionLogica1();
                }
                break;
            case 203: // true
                expresionLogica1();
                break;
            case 204: // false
                expresionLogica1();
                break;
            default:
                expresionRelacional();
                expresionLogica1();
        }
    }

    private void expresionRelacional() {
        expresionNumerica();
        if (p.token == 108 || p.token == 109 || p.token == 110 || p.token == 111 || p.token == 112 || p.token == 113) { // operador relacional >, < >=, <=, <>, =
            p = p.sig;
            expresionNumerica();
        } else {
            imprimirMensajeError(317);
        }
    }

    private void leer() {
        p = p.sig;
        if (p.token == 100) { //identificador
            p = p.sig;
            if (p.token == 120) { // ,
                leer();
            }
        } else {
            imprimirMensajeError(302);
        }

    }

    private void escribir() {
        p = p.sig;
        if (p.token == 100) { //identificador
            p = p.sig;
            if (p.token == 120) { // ,
                escribir();
            }
        } else {
            imprimirMensajeError(302);
        }
    }

    private void si() {
        expresionLogica();
        if (p.token == 208) { //entonces
            accion();
            if (p.token == 210) { // sino
                accion();
            }
            if (p.token == 209) { //fin_si
                p = p.sig;
            } else {
                imprimirMensajeError(316); // espera fin-si
            }
        } else {
            imprimirMensajeError(316); // espera fin-si
        }
    }

    private void mientras() {
        expresionLogica();
        if (p.token == 213) { //hacer
            accion();
            if (p.token == 212) { //fin-mientras   
                p = p.sig;
            } else {
                imprimirMensajeError(315);
            }
        }
    }

    private void expresionLogica1() {
        if (p.token == 200 || p.token == 201) { // and || or               
            expresionLogica();
            expresionLogica1();
        }
    }

    private void checarVariablesSemantico() {
        while (recorridoSemantico != null) {
            if (p.lexema.equals(recorridoSemantico.lexema)) {
                imprimirMensajeErrorSemantico(331); // Error semantico variable ya decalrada
            }
            recorridoSemantico = recorridoSemantico.sig;
        }
        recorridoSemantico = cabezaSemantico;
    }
}
